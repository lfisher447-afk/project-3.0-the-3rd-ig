// Notification & Site Permissions Engine (notifications.ts)

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'security';
  timestamp: number;
  read?: boolean;
}

type NotificationListener = (notifications: AppNotification[]) => void;

let notificationQueue: AppNotification[] = [
  {
    id: 'init-1',
    title: 'Signal Room Vault Online',
    message: '1000x Hardened Anti-Screenshot & Linewize Bypass Engine is Active.',
    type: 'security',
    timestamp: Date.now(),
  },
];

const listeners: Set<NotificationListener> = new Set();

export function subscribeNotifications(listener: NotificationListener): () => void {
  listeners.add(listener);
  listener([...notificationQueue]);
  return () => listeners.delete(listener);
}

function notifyListeners() {
  const current = [...notificationQueue];
  listeners.forEach((fn) => fn(current));
}

export function addNotification(title: string, message: string, type: AppNotification['type'] = 'info') {
  const notif: AppNotification = {
    id: 'n_' + Math.random().toString(36).substring(2, 9),
    title,
    message,
    type,
    timestamp: Date.now(),
    read: false,
  };

  notificationQueue = [notif, ...notificationQueue.slice(0, 49)];
  notifyListeners();

  // Send system desktop Web Notification if permission granted
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body: message,
        icon: '/vite.svg',
      });
    } catch (e) {
      console.warn('[System Notification Notice]', e);
    }
  }
}

export function clearNotifications() {
  notificationQueue = [];
  notifyListeners();
}

export async function requestBrowserNotificationPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    addNotification('Notifications Unsupported', 'Your browser environment does not support system notifications.', 'warning');
    return 'denied';
  }

  try {
    const res = await Notification.requestPermission();
    if (res === 'granted') {
      addNotification('Permissions Granted', 'Browser desktop notifications enabled for Signal Room Vault.', 'success');
    } else {
      addNotification('Permission Denied', 'Browser notifications were blocked.', 'warning');
    }
    return res;
  } catch (err) {
    console.warn('[Notification Permission Error]', err);
    return 'denied';
  }
}

export function checkSitePermissionsState() {
  return {
    notifications: 'Notification' in window ? Notification.permission : 'unsupported',
    microphone: 'mediaDevices' in navigator ? 'available' : 'unsupported',
    storage: 'indexedDB' in window ? 'available' : 'unsupported',
    serviceWorker: 'serviceWorker' in navigator ? 'available' : 'unsupported',
  };
}
